import java.util.Scanner;

public class MyProgram {
    
    public static void main(String[] args) {
        
        String borderAndSpace = "============================================================\n";
        String end = "};" + "\n" + "\n" + "------------------------------------------------------------" + "\n" + "\n" + "Highlight the array then right click to copy." + "\n" + "\n";
        boolean stop = false;
        
        while (stop == false) {
            Scanner input = new Scanner(System.in);
            
            System.out.println(borderAndSpace);
            
            System.out.println("Welcome to my array maker! Press ENTER to continue!");
            System.out.println();
            
            System.out.println(borderAndSpace);
            
            String enter = input.nextLine();
            
            
            Questions qOne = new Questions(enter);
            //Prints arrayType question
            qOne.questionOne();
            
            String arrayType = input.nextLine();
            
            
            Questions qTwo = new Questions(arrayType);
            //prints ending num question
            qTwo.questionTwo();
            
            String convert = input.nextLine();
            
            
            Questions qThree = new Questions(convert);
            //prints arrayTitle question
            qThree.questionThree();
            
            String arrayTitle = input.nextLine();
            System.out.println();
            
            System.out.println(borderAndSpace);
            
            
            if(arrayType.equalsIgnoreCase("String")) {
                
                System.out.println("Words or numbers?");
                System.out.println();
                
                System.out.println(borderAndSpace);
                
                String typeArray = input.nextLine();
                System.out.println();
                
                System.out.println(borderAndSpace);
                
                if (typeArray.equalsIgnoreCase("Words")) {
                    
                    int endingNum = Integer.parseInt(convert);
                    
                    String[] responses = new String[endingNum];
                    
                    System.out.println("Type as many as you need then type done without typing anything." + "\n");
                    
                    int secondUrNum = endingNum;
                    
                    for (int i = 0; i < secondUrNum; i++) {
                        
                        String personResponses = input.nextLine();
                        responses[i] = personResponses;
                        
                        if (secondUrNum == i + 1) {
                            
                            System.out.println();
                            System.out.println(borderAndSpace);
                            
                            System.out.println("Press enter");
                            String done = input.nextLine();
                            
                            System.out.println(borderAndSpace);
                            
                            if (done.equalsIgnoreCase("")) {
                                
                                int num = 1;
                                int urNum = endingNum;
                              
                                System.out.print("String[] " + arrayTitle + " = {");
                                
                                for (int j = 0; j < urNum; j++) {
                                    
                                    String line = '"' + responses[i--] + '"' + ", ";
                                    System.out.print(line);
                                    num++;
                                    
                                    if (num == urNum + 1) {
                                        
                                        line = line.substring(0, line.length() - 2);
                                        System.out.print(line);
                                        System.out.print(end);
                                        
                                        System.out.println("What to make another one? (Yes/No)");
                                            
                                        String stopQuestion = input.nextLine();
                                        System.out.println();
                                        
                                        if (stopQuestion.equalsIgnoreCase("Yes")) {
                                            
                                            break;
                                            
                                        } else if (stopQuestion.equalsIgnoreCase("No")) {
                                            
                                            stop = true;
                                            
                                            while (stop == true) {
                                                System.exit(1);
                                            }
                                        }
                                    }
                                }
                            }
                        }    
                    }
                } else if (typeArray.equalsIgnoreCase("numbers")) {
                    
                    int endingNum = Integer.parseInt(convert);
                    
                    int secondNum = 1;
                    int urNum = endingNum;
                    String quoteMark = "" + '"';
                    
                    System.out.print("String[] " + arrayTitle + " = { " + quoteMark + "0" + quoteMark + ", ");
                    
                    for (int i = 0; i < urNum; i++) {
                        
                        String line = quoteMark + secondNum++ + quoteMark + ", ";
                        System.out.print(line);
                        
                        if (secondNum == urNum + 1) {
                            
                            line = line.substring(0, line.length() - 2);
                            System.out.print(line);
                            System.out.print(end);
                            
                            System.out.println("What to make another one? (Yes/No)");
                        
                            String stopQuestion = input.nextLine();
                            System.out.println();
                            
                            if (stopQuestion.equalsIgnoreCase("Yes")) {
                                
                                break;
                                
                            } else if (stopQuestion.equalsIgnoreCase("No")) {
                                
                                stop = true;
                                
                                while (stop == true) {
                                    System.exit(1);
                                }
                            }
                        }
                        
                    }
                    
                }  
                
            } else if(arrayType.equalsIgnoreCase("int")) {
                
                int endingNum = Integer.parseInt(convert);
                
                int num = 1;
                int urNum = endingNum;
                  
                System.out.print("int[] " + arrayTitle + " = { 0,");
                
                for (int i = 0; i < urNum; i++) {
                    
                    String line = " " + num++ + ",";
                    System.out.print(line);
                    
                    if (num == urNum + 1) {
                        
                        line = line.substring(0, line.length()-1);
                        System.out.print(line);
                        System.out.print(end);
                        
                        System.out.println("What to make another one? (Yes/No)");
                        
                        String stopQuestion = input.nextLine();
                        System.out.println();
                        
                        if (stopQuestion.equalsIgnoreCase("Yes")) {
                            
                            break;
                            
                        } else if (stopQuestion.equalsIgnoreCase("No")) {
                            
                            stop = true;
                            
                            while (stop == true) {
                                System.exit(1);
                            }
                        }
                    }
                    
                }
            
            } else if(arrayType.equalsIgnoreCase("double")) {
                
                int endingNum = Integer.parseInt(convert);
                
                double num = 1.0;
                int urNum = endingNum;
                  
                System.out.print("double[] " + arrayTitle + " = { 0.0,");
                
                for (int i = 0; i < urNum; i++) {
                    
                    String line = " " + num++ + ",";
                    System.out.print(line);
                    
                    if (num == urNum + 1) {
                        
                        line = line.substring(0, line.length()-1);
                        System.out.print(line);
                        System.out.print(end);
                        
                        System.out.println("What to make another one? (Yes/No)");
                        
                        String stopQuestion = input.nextLine();
                        System.out.println();
                        
                        if (stopQuestion.equalsIgnoreCase("Yes")) {
                            
                            break;
                            
                        } else if (stopQuestion.equalsIgnoreCase("No")) {
                            
                            stop = true;
                            
                            while (stop == true) {
                                System.exit(1);
                            }
                        }
                    }
                }
            } else if(arrayType.equalsIgnoreCase("boolean")) {
                
                int endingNum = Integer.parseInt(convert);
                
                double num = 1.0;
                int urNum = endingNum;
                
                System.out.print("Start with true or false?");
                
                String tOrF = input.nextLine();
                
                if (tOrF.equalsIgnoreCase("true")) {
                    
                    System.out.print("For every true you want how many falses?");
                    
                    int howManyTOrF = input.nextInt();
                    System.out.println();
                  
                    System.out.print("boolean[] " + arrayTitle + " = { true, false,");
                    
                    for (int i = 0; i < urNum; i++) {
                        
                        if (howManyTOrF % 2 == 0) {
                            
                            for (int k = 0; k < howManyTOrF; k++) {
                                
                                String line = " " + "false" + ",";
                                System.out.print(line);
                                num++;
                                
                                if (k % 2 == 0) {
                                    
                                    String line1 = " " + "true" + ",";
                                    System.out.print(line1);
                                    num++;
                                    
                                    if (num == urNum + 1) {
                                        
                                        line = line.substring(0, line.length()-1);
                                        System.out.print(line);
                                        System.out.print(end);
                                        
                                        System.out.println("What to make another one? (Yes/No)");
                                        
                                        String stopQuestion = input.nextLine();
                                        System.out.println();
                                        
                                        if (stopQuestion.equalsIgnoreCase("Yes")) {
                                            
                                            break;
                                            
                                        } else if (stopQuestion.equalsIgnoreCase("No")) {
                                            
                                            stop = true;
                                            
                                            while (stop == true) {
                                                System.exit(1);
                                            }
                                        }
                                    }
                                }    
                            }
                        } else {
                            
                        }
                        
                    }
                }
            }
        }
    }
}