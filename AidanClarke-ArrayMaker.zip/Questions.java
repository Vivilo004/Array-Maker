public class Questions {
    
    private String foo;
    String borderAndSpace = "============================================================\n";
    
    public Questions (String bar){
        foo = bar;
    }
    
    public void questionOne()
    {
        System.out.println(borderAndSpace);
        
        System.out.println("What type of array? (String/Int/Double)");
        System.out.println();
        
        System.out.println(borderAndSpace);
    }
    
    public void questionTwo()
    {
        System.out.println();
            
        System.out.println(borderAndSpace);
        
        System.out.println("When do you want it to end? (1-2147483647)");
        System.out.println();
        
        System.out.println(borderAndSpace);
    }
    
    public void questionThree()
    {
        System.out.println();
            
        System.out.println(borderAndSpace);
        
        System.out.println("What do you want the array to be called?");
        System.out.println();
        
        System.out.println(borderAndSpace);
    }
    
    
}